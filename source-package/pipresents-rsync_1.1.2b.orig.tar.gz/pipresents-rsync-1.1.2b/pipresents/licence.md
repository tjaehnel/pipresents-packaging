Pi Presents
-----------

Copyright (c) 2013, Ken Thompson. Contact for licencing: http://www.museumoftechnology.org.uk/form.php . For technical queries please use Github or RPi Forum.

Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby granted, provided that the above copyright notice and this permission notice appear in all copies.

This software is Careware. If you are using this software in a profit making situation or distributing this software as part of a profit making product please consider sharing some of those profits with the charity with which I am associated and which inspired Pi Presents.

*  The Museum of Technology, a super little museum who are currenty building themselves a larger home.

      http://www.museumoftechnology.org.uk    Use the 'Donate Now' button.

Let us know at http://www.museumoftechnology.org.uk/form.php so we can thank you.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.